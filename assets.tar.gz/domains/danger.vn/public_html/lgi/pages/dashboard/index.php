<div class="clr"></div>
<?php /*
<div class="row">
	<div class="col col-9">
		<div class="block block-main block-dashboard">
			<label>Doanh thu ước tính</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-3">
				<span>Đầu ngày tới giờ</span>
				<b class="price">0</b>
				</div>
				<div class="col col-3">
				<span>Hôm qua</span>
				<b class="price">0</b>
				</div>
				<div class="col col-3">
				<span>7 ngày qua</span>
				<b class="price">0</b>
				</div>
				<div class="col col-3">
				<span>Tháng này</span>
				<b class="price">0</b>
				</div>
			</div>
		</div>
	</div>
	<div class="col col-3">
		<div class="block block-main block-dashboard">
			<label>Tổng doanh thu</label>
			<span></span>
			<b>0</b>
		</div>
	</div>
	<div class="col col-12">
		<div class="block block-dashboard">
			<label>Dữ liệu truy cập</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-2">
				<span>Đầu ngày tới giờ</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Hôm qua</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>7 ngày qua</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Tháng này</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Tháng trước</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Toàn bộ</span>
				<b>0</b>
				</div>
			</div>
		</div>
	</div>
	<div class="col col-6">
		<div class="block block-dashboard">
			<label>Hiệu suất bán hàng</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-4">
				<span>Tổng đơn hàng</span>
				<b>0</b>
				</div>
				<div class="col col-4">
				<span>Thành công</span>
				<b>0</b>
				</div>
				<div class="col col-4">
				<span>Bị hủy</span>
				<b>0</b>
				</div>
			</div>
		</div>
	</div>
	<div class="col col-6">
		<div class="block block-dashboard">
			<label>Dữ liệu kinh doanh</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-4">
				<span>Tổng bài viết</span>
				<b>0</b>
				</div>
				<div class="col col-4">
				<span>Tổng sản phẩm</span>
				<b>0</b>
				</div>
				<div class="col col-4">
				<span>Tổng dịch vụ</span>
				<b>0</b>
				</div>
			</div>
		</div>
	</div>
	<div class="col col-12">
		<div class="block block-dashboard">
			<label>Tỉ lệ chuyển đổi</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-2">
				<span>Đầu ngày tới giờ</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Hôm qua</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>7 ngày qua</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Tháng này</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Tháng trước</span>
				<b>0</b>
				</div>
				<div class="col col-2">
				<span>Toàn bộ</span>
				<b>0</b>
				</div>
			</div>
		</div>
		<div class="block block-dashboard">
			<label>Thống kê thành viên</label>
			<div class="clr"></div>
			<div class="row">
				<div class="col col-20">
				<span>Khách hàng mới</span>
				<b>0</b>
				</div>
				<div class="col col-20">
				<span>Khách lẻ</span>
				<b>0</b>
				</div>
				<div class="col col-20">
				<span>Khách sỉ</span>
				<b>0</b>
				</div>
				<div class="col col-20">
				<span>Cộng tác viên</span>
				<b>0</b>
				</div>
				<div class="col col-20">
				<span>Nhân sự</span>
				<b>0</b>
				</div>
			</div>
		</div>
	</div>
</div>
*/