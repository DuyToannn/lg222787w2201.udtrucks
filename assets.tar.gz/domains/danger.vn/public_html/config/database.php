<?php class Database{
public static $host = 'localhost';
public static $driver = 'mysqli';
public static $prefix = 'eso_';
public static $name = 'm12d09d01_db';
public static $user = 'm12d09d01_db';
public static $password = 'm12d09d01_db';
public static $session = 'Yex4moyfYS';
}
?>