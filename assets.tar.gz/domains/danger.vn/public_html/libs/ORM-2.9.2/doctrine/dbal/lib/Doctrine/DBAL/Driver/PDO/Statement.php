<?php

namespace Doctrine\DBAL\Driver\PDO;

use Doctrine\DBAL\Driver\PDOStatement;

class Statement extends PDOStatement
{
}
