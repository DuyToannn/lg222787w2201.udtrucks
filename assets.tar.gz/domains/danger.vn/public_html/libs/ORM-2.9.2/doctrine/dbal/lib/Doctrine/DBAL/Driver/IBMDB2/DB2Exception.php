<?php

namespace Doctrine\DBAL\Driver\IBMDB2;

use Doctrine\DBAL\Driver\AbstractDriverException;

/**
 * @deprecated Use {@link Exception} instead
 *
 * @psalm-immutable
 */
class DB2Exception extends AbstractDriverException
{
}
