<?php

namespace Doctrine\DBAL\Driver\IBMDB2;

final class Statement extends DB2Statement
{
}
